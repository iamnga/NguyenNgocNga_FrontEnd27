import React, { Component } from 'react'

export default class Ghe extends Component {

    constructor(props){
        super(props);

        this.state = {
            listClass : this.props.ghe.TrangThai? "btn btn-danger" : "btn btn-secondary"
        }
    }

    chonGhe = (soGhe) => {
        if (this.state.listClass == "btn btn-success" || this.state.listClass == "btn btn-danger"){
            return
        }
        this.setState({
            listClass: "btn btn-success",
            dachon: true
        })
        this.props.gheDaChon(soGhe);
    }

    render() {
        let {SoGhe,TenGhe,Gia,TrangThai} = this.props.ghe
        return (
            <button className={this.state.listClass} onClick={() => this.chonGhe(SoGhe)}>{SoGhe}</button>
        )
    }
}
