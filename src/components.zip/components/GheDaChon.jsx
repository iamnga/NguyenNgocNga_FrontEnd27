import React, { Component } from 'react'

export default class GheDaChon extends Component {

    renderGheDaChon = () => {
        return this.props.mangGheDaChon.map((ghe, index) => {
            return(
                <p key={index}>Ghế số {ghe.SoGhe} $ {ghe.Gia} <a href="#" onClick={() => this.props.huyChon(ghe.SoGhe)}>[Hủy]</a></p>
            );
        })
    }

    render() {
        return (
            <div>
                {this.renderGheDaChon()}
            </div>
        )
    }
}
